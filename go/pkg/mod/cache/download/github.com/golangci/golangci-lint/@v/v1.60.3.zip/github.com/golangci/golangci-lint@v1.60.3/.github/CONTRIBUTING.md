See [contributing quick start](https://golangci-lint.run/contributing/quick-start/) on our website.
